# Submission Pack — FoodFlow & MediQueue

## Included
- `FoodFlow_Final_Report_EDIT_ME.docx` — editable MP1 report
- `MediQueue_Final_Report_EDIT_ME.docx` — editable MP2 report
- `FoodFlow_MediQueue_Presentation_EDIT_ME.pptx` — combined presentation
- `mini_projects_bundle/` — source code bundle from the existing project package

## Important before submitting
1. Replace every `[bracketed placeholder]` with your actual college, department, name, roll number, guide, and academic year.
2. Add genuine screenshots from the live demos or locally running Flask apps to the Results section.
3. Fill the Actual Result cells in the test tables only after performing each test.
4. Check your department's exact cover/certificate requirements and page numbering.
5. GitHub Pages hosts the static demos. The Flask/Python backend is a separate app and is not run by GitHub Pages.

## Live demos
- FoodFlow: https://ashishkarche0701-star.github.io/foodflow-mini-project/
- MediQueue: https://ashishkarche0701-star.github.io/mediqueue-mini-project/

## Repositories
- FoodFlow: https://github.com/ashishkarche0701-star/foodflow-mini-project
- MediQueue: https://github.com/ashishkarche0701-star/mediqueue-mini-project

## Accuracy note
The report and presentation are editable academic drafts. Do not claim backend deployment, full testing, or results that have not actually been verified.
