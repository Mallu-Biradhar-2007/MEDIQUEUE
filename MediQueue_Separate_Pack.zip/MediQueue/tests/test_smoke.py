import unittest, tempfile, os
import app as med_app

class MediQueueSmokeTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.NamedTemporaryFile(delete=False)
        self.tmp.close()
        med_app.DB = self.tmp.name
        med_app.init_db()
        self.client = med_app.app.test_client()
    def tearDown(self):
        os.unlink(self.tmp.name)
    def test_home(self):
        self.assertEqual(self.client.get("/").status_code, 200)
    def test_health(self):
        self.assertEqual(self.client.get("/health").json["status"], "ok")

if __name__ == "__main__": unittest.main()
