from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3, os
from datetime import datetime

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-for-production")
DB = os.path.join(os.path.dirname(__file__), "mediqueue.db")

class PatientNode:
    def __init__(self, patient_id, name, age, complaint, priority, status, created_at):
        self.patient_id, self.name, self.age = patient_id, name, age
        self.complaint, self.priority, self.status = complaint, priority, status
        self.created_at, self.next = created_at, None

class PatientLinkedList:
    """Singly linked list used for patient records; SQLite provides persistence."""
    def __init__(self):
        self.head = None
        self.tail = None
    def append(self, node):
        if not self.head:
            self.head = self.tail = node
        else:
            self.tail.next = node
            self.tail = node
    def to_list(self):
        result, current = [], self.head
        while current:
            result.append(current)
            current = current.next
        return result

def connect():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    with connect() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS patients(
            id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, age INTEGER NOT NULL,
            complaint TEXT NOT NULL, priority TEXT NOT NULL, status TEXT NOT NULL,
            created_at TEXT NOT NULL)""")
init_db()

def all_patients():
    with connect() as con:
        rows = con.execute("SELECT * FROM patients ORDER BY id ASC").fetchall()
    linked = PatientLinkedList()
    for row in rows:
        linked.append(PatientNode(row["id"], row["name"], row["age"], row["complaint"],
                                  row["priority"], row["status"], row["created_at"]))
    return linked.to_list()

def scheduled_waiting():
    patients = [p for p in all_patients() if p.status == "Waiting"]
    # Stable sorting retains arrival order within each priority group.
    return sorted(patients, key=lambda p: 0 if p.priority == "Emergency" else 1)

@app.route("/")
def index():
    patients = all_patients()
    waiting = scheduled_waiting()
    return render_template("index.html", patients=patients, waiting=waiting)

@app.post("/patients")
def add_patient():
    name = request.form.get("name", "").strip()
    complaint = request.form.get("complaint", "").strip()
    priority = request.form.get("priority", "Normal")
    try:
        age = int(request.form.get("age", ""))
        if not name or not complaint or not 0 <= age <= 120 or priority not in {"Emergency", "Normal"}:
            raise ValueError
    except ValueError:
        flash("Please enter a name, valid age (0–120), complaint, and priority.", "error")
        return redirect(url_for("index"))
    with connect() as con:
        con.execute("INSERT INTO patients(name,age,complaint,priority,status,created_at) VALUES(?,?,?,?,?,?)",
                    (name, age, complaint, priority, "Waiting", datetime.now().isoformat(timespec="minutes")))
    flash(f"Patient {name} registered. This demo queue is for academic use only.", "success")
    return redirect(url_for("index"))

@app.post("/patients/<int:patient_id>/call")
def call_patient(patient_id):
    queue = scheduled_waiting()
    if not queue or queue[0].patient_id != patient_id:
        flash("Please call the next patient according to emergency-first scheduling.", "error")
    else:
        with connect() as con:
            con.execute("UPDATE patients SET status='In Treatment' WHERE id=?", (patient_id,))
        flash(f"Patient #{patient_id} moved to In Treatment.", "success")
    return redirect(url_for("index"))

@app.post("/patients/<int:patient_id>/complete")
def complete_patient(patient_id):
    with connect() as con:
        con.execute("UPDATE patients SET status='Treated' WHERE id=? AND status='In Treatment'", (patient_id,))
    flash(f"Treatment status updated for patient #{patient_id}.", "success")
    return redirect(url_for("index"))

@app.post("/patients/<int:patient_id>/delete")
def delete_patient(patient_id):
    with connect() as con:
        con.execute("DELETE FROM patients WHERE id=?", (patient_id,))
    flash(f"Patient record #{patient_id} deleted.", "success")
    return redirect(url_for("index"))

@app.route("/health")
def health():
    return {"status": "ok", "app": "MediQueue"}

if __name__ == "__main__":
    app.run(debug=True)
