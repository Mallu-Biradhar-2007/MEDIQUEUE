# MediQueue — Hospital Emergency Management System (MP2)

A Flask website demonstrating a singly linked list for patient records and emergency-first scheduling with FIFO order within each priority group.

## Features
- Patient registration and record table
- Emergency-first waiting queue; stable arrival order within priority
- Call-next validation, treatment completion and record deletion
- SQLite persistence plus a Python singly linked list used to build records
- Responsive dashboard and educational safety notice

## Run locally
1. Install Python 3.10+.
2. Create and activate a virtual environment.
3. Run `pip install -r requirements.txt`.
4. Run `python app.py`.
5. Open http://127.0.0.1:5000.

## Data structures
- `PatientLinkedList`: singly linked list with head and tail pointers
- `scheduled_waiting()`: stable priority scheduling; Emergency precedes Normal and arrival order is preserved within each class
- SQLite: stores records across application restarts

## Safety
This is a fictional classroom demonstration, not a clinical triage tool. Do not enter real patient data or use it for medical decisions. Replace the development secret key and disable debug mode before any public deployment.
